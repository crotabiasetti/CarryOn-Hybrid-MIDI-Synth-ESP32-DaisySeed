#include "esp_log.h"
#include "usb/usb_host.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "USB_MIDI_UART";

static usb_host_client_handle_t client_hdl = NULL;
static usb_device_handle_t dev_hdl = NULL;
static usb_transfer_t *xfer_in = NULL;

static uint8_t dev_addr = 0;

#define MIDI_IF_NUM     1
#define MIDI_EP_IN      0x82
#define MIDI_MAX_PKT    64

#define UART_PORT       UART_NUM_1
#define UART_TX_PIN     17

// ---------------- CONTROLLI ----------------
#define NUM_POTS   15
#define NUM_BTNS   8

// --- ADC1: 10 canali ---
static const adc_channel_t pot_adc1_channels[10] = {
    ADC_CHANNEL_0, ADC_CHANNEL_1, ADC_CHANNEL_2, ADC_CHANNEL_3, ADC_CHANNEL_4,
    ADC_CHANNEL_5, ADC_CHANNEL_6, ADC_CHANNEL_7, ADC_CHANNEL_8, ADC_CHANNEL_9
};

// --- ADC2: 5 canali ---
static const adc_channel_t pot_adc2_channels[5] = {
    ADC_CHANNEL_0, ADC_CHANNEL_1, ADC_CHANNEL_2, ADC_CHANNEL_3, ADC_CHANNEL_4
};

// --- GPIO35 → GPIO42 ---
static const gpio_num_t btn_pins[NUM_BTNS] = {
    GPIO_NUM_35, GPIO_NUM_36, GPIO_NUM_37, GPIO_NUM_38,
    GPIO_NUM_45, GPIO_NUM_46, GPIO_NUM_47, GPIO_NUM_48
};

// CC assegnati
static const uint8_t pot_cc[NUM_POTS] = {
    10, 11, 12, 13, 14, 15, 16, 17,
    18, 19, 20, 21, 22, 23, 24
};

static const uint8_t btn_cc[NUM_BTNS] = {
    30, 31, 32, 33, 34, 35, 36, 37
};

// Stati
static uint8_t pot_last_val[NUM_POTS] = {0};
static uint8_t btn_last_raw[NUM_BTNS] = {1};

// ---------------- UART ----------------
static void send_uart_midi(uint8_t status, uint8_t data1, uint8_t data2)
{
    uint8_t msg[3] = {status, data1, data2};
    uart_write_bytes(UART_PORT, (const char *)msg, 3);
}

// ---------------- ADC UTILS ----------------
static uint8_t map_to_midi(int raw)
{
    if (raw < 0) raw = 0;
    if (raw > 4095) raw = 4095;
    return (raw * 127) / 4095;
}

// ------------- PARSE MIDI -------------
static void parse_midi_packet(const uint8_t *p)
{
    uint8_t status = p[1];
    uint8_t data1  = p[2];
    uint8_t data2  = p[3];

    send_uart_midi(status, data1, data2);
}

// --------- TRANSFER CALLBACK ----------
static void in_transfer_cb(usb_transfer_t *transfer)
{
    if (transfer->status == USB_TRANSFER_STATUS_COMPLETED &&
        transfer->actual_num_bytes > 0) {

        int n = transfer->actual_num_bytes & ~0x03;
        for (int i = 0; i < n; i += 4)
            parse_midi_packet(&transfer->data_buffer[i]);
    }

    transfer->num_bytes = MIDI_MAX_PKT;
    usb_host_transfer_submit(transfer);
}

// --------- CLIENT EVENT CALLBACK -------
static void usb_client_event_cb(const usb_host_client_event_msg_t *event_msg, void *arg)
{
    switch (event_msg->event) {
        case USB_HOST_CLIENT_EVENT_NEW_DEV:
            dev_addr = event_msg->new_dev.address;
            ESP_LOGI(TAG, "Nuovo device USB, address=%d", dev_addr);
            break;

        case USB_HOST_CLIENT_EVENT_DEV_GONE:
            ESP_LOGI(TAG, "Device USB disconnesso");
            dev_addr = 0;
            dev_hdl = NULL;
            break;
    }
}

// --------- USB LIB TASK ----------
static void usb_lib_task(void *arg)
{
    uint32_t evt_flags = 0;

    while (1) {
        usb_host_lib_handle_events(10, &evt_flags);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

// --------------- MIDI TASK -------------
static void midi_task(void *arg)
{
    usb_host_client_config_t client_config = {
        .is_synchronous = false,
        .max_num_event_msg = 10,
        .async = {
            .client_event_callback = usb_client_event_cb,
            .callback_arg = NULL
        }
    };

    usb_host_client_register(&client_config, &client_hdl);

    while (dev_hdl == NULL) {
        usb_host_client_handle_events(client_hdl, 100);

        if (dev_addr != 0 && dev_hdl == NULL)
            usb_host_device_open(client_hdl, dev_addr, &dev_hdl);

        vTaskDelay(pdMS_TO_TICKS(50));
    }

    usb_host_interface_claim(client_hdl, dev_hdl, MIDI_IF_NUM, 0);

    usb_host_transfer_alloc(MIDI_MAX_PKT, 0, &xfer_in);

    xfer_in->device_handle     = dev_hdl;
    xfer_in->bEndpointAddress  = MIDI_EP_IN;
    xfer_in->callback          = in_transfer_cb;
    xfer_in->num_bytes         = MIDI_MAX_PKT;

    usb_host_transfer_submit(xfer_in);

    while (1) {
        usb_host_client_handle_events(client_hdl, 100);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

// --------- CONTROLS TASK ----------
static void controls_task(void *arg)
{
    adc_oneshot_unit_handle_t adc1_handle;
    adc_oneshot_unit_handle_t adc2_handle;

    adc_oneshot_unit_init_cfg_t init_cfg1 = { .unit_id = ADC_UNIT_1 };
    adc_oneshot_unit_init_cfg_t init_cfg2 = { .unit_id = ADC_UNIT_2 };

    adc_oneshot_new_unit(&init_cfg1, &adc1_handle);
    adc_oneshot_new_unit(&init_cfg2, &adc2_handle);

    adc_oneshot_chan_cfg_t cfg = {
        .bitwidth = ADC_BITWIDTH_12,
        .atten = ADC_ATTEN_DB_11,
    };

    for (int i = 0; i < 10; i++)
        adc_oneshot_config_channel(adc1_handle, pot_adc1_channels[i], &cfg);

    for (int i = 0; i < 5; i++)
        adc_oneshot_config_channel(adc2_handle, pot_adc2_channels[i], &cfg);

    // Stati iniziali
    for (int i = 0; i < NUM_POTS; i++) {
        int raw = 0;

        if (i < 10)
            adc_oneshot_read(adc1_handle, pot_adc1_channels[i], &raw);
        else
            adc_oneshot_read(adc2_handle, pot_adc2_channels[i - 10], &raw);

        uint8_t v = map_to_midi(raw);
        pot_last_val[i] = v;

        send_uart_midi(0xB0, pot_cc[i], v);
    }

    for (int i = 0; i < NUM_BTNS; i++) {
        uint8_t raw = gpio_get_level(btn_pins[i]);
        btn_last_raw[i] = raw;

        uint8_t value = (raw == 0) ? 127 : 0;
        send_uart_midi(0xB0, btn_cc[i], value);
    }

    while (1) {

        for (int i = 0; i < 10; i++) {
            int raw = 0;
            adc_oneshot_read(adc1_handle, pot_adc1_channels[i], &raw);
            uint8_t v = map_to_midi(raw);

            if (abs(v - pot_last_val[i]) > 1) {
                pot_last_val[i] = v;
                send_uart_midi(0xB0, pot_cc[i], v);
            }
        }

        for (int i = 0; i < 5; i++) {
            int raw = 0;
            adc_oneshot_read(adc2_handle, pot_adc2_channels[i], &raw);
            uint8_t v = map_to_midi(raw);

            int idx = 10 + i;
            if (abs(v - pot_last_val[idx]) > 1) {
                pot_last_val[idx] = v;
                send_uart_midi(0xB0, pot_cc[idx], v);
            }
        }

        for (int i = 0; i < NUM_BTNS; i++) {
            uint8_t raw = gpio_get_level(btn_pins[i]);

            if (raw != btn_last_raw[i]) {

                vTaskDelay(pdMS_TO_TICKS(5));
                raw = gpio_get_level(btn_pins[i]);

                if (raw != btn_last_raw[i]) {
                    btn_last_raw[i] = raw;

                    uint8_t value = (raw == 0) ? 127 : 0;
                    send_uart_midi(0xB0, btn_cc[i], value);
                }
            }
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

// --------- INIT CONTROLLI ----------
static void init_controls(void)
{
    for (int i = 0; i < NUM_BTNS; i++) {
        gpio_config_t io_conf = {
            .pin_bit_mask = (1ULL << btn_pins[i]),
            .mode = GPIO_MODE_INPUT,
            .pull_up_en = GPIO_PULLUP_ENABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE
        };
        gpio_config(&io_conf);

        btn_last_raw[i] = gpio_get_level(btn_pins[i]);
    }

    xTaskCreate(controls_task, "controls_task", 4096, NULL, 4, NULL);
}

// ----------------- MAIN ----------------
void app_main(void)
{
    uart_config_t uart_config = {
        .baud_rate = 31250,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };

    uart_driver_install(UART_PORT, 256, 0, 0, NULL, 0);
    uart_param_config(UART_PORT, &uart_config);
    uart_set_pin(UART_PORT, UART_TX_PIN,
                 UART_PIN_NO_CHANGE,
                 UART_PIN_NO_CHANGE,
                 UART_PIN_NO_CHANGE);

    init_controls();

    usb_host_config_t host_config = {
        .skip_phy_setup = false,
        .intr_flags = ESP_INTR_FLAG_LEVEL1,
    };
    usb_host_install(&host_config);

    xTaskCreate(usb_lib_task, "usb_lib_task", 4096, NULL, 6, NULL);
    xTaskCreate(midi_task, "midi_task", 4096, NULL, 5, NULL);
}
