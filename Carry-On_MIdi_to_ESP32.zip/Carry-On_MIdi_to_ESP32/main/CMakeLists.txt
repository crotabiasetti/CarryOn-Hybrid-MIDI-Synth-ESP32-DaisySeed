idf_component_register(
    SRCS "Carry-on_MIDI_to_ESP32.c"
    INCLUDE_DIRS "."
    REQUIRES usb
    PRIV_REQUIRES esp_driver_uart
    REQUIRES driver usb esp_adc
)

