#include "daisy_seed.h"
#include "daisysp.h"

using namespace daisy;
using namespace daisysp;

DaisySeed hw;

// ----------------------------
// STRUTTURE
// ----------------------------
struct Voice
{
    Oscillator osc1;
    Oscillator osc2;
    Adsr       amp_env;
    Adsr       filt_env;
    Adsr       vib_env; // LFO per modulazione Ampiezza (non usato ora)
    Svf        svf;
    bool       gate;
    float      freq;
    int        note;
    float      osc_mix;
    float      detune;

    float      amp_env_last;
};

bool D0 = false; // cutoff fisso
bool D1 = false; // cutoff da LFO vs env
bool D2 = false; // solo osc1 vs mix osc1/osc2
bool D3 = false; // highpass vs lowpass
bool D4 = false; // feedback input
bool D5 = false; // chorus
bool D6 = false; // RECORD
bool D7 = false; // PLAY

// ----------------------------
// ARPEGGIATORE
// ----------------------------
enum ArpMode
{
    ARP_UP = 0,
    ARP_DOWN,
    ARP_UPDOWN,
    ARP_RANDOM
};

bool    arp_enabled = false;
int     arp_octaves = 2;     // 2..5, da Ad10
ArpMode arp_mode     = ARP_UP; // da Ad10

int held_notes[16];
int held_count = 0;

int arp_pool[16 * 5]; // note tenute (fino a 16) espanse su fino a 5 ottave
int arp_pool_len = 0;
int arp_step      = 0;
int arp_dir       = 1; // usato in modalita' UP/DOWN per il ping-pong

int arp_voice        = -1; // voce dedicata all'arpeggiatore
int arp_current_note = -1;

size_t arp_sample_cnt      = 0;
size_t arp_interval_samples = 4800; // ricalcolato ogni giro dal loop principale (Ad11)

uint32_t arp_rng_state = 22222;

// tempo di riferimento per le suddivisioni musicali dell'arpeggiatore
// (per ora fisso; in futuro si puo' agganciare a un potenziometro o al clock MIDI)
float arp_bpm = 120.0f;

// suddivisioni musicali selezionabili da Ad11, come multiplo della durata
// di una nota da un quarto (60/bpm secondi). Ordinate da piu' veloce a piu' lenta.
const float ARP_DIVISIONS[8] =
{
    1.0f / 6.0f, // 1/16 in terzina (la piu' veloce)
    0.25f,       // 1/16
    1.0f / 3.0f, // 1/8 in terzina
    0.5f,        // 1/8
    2.0f / 3.0f, // 1/4 in terzina
    1.0f,        // 1/4
    2.0f,        // 1/2
    4.0f         // 1/1, intera (la piu' lenta)
};

// ----------------------------
// SDRAM LOOPER
// ----------------------------
#define SDRAM_SIZE (8 * 1024 * 1024 / sizeof(float)) // ~2M samples (float)
float *sdram_buffer = (float*)0xC0000000;

size_t write_idx    = 0;
size_t read_idx     = 0;
size_t recorded_len = 0;

bool is_recording = false;
bool is_playing   = false;

float cutoff, g_cutoff = 1000.0f;
float sig;
float ratio = 0.1f;
float InputLevel = 0.5f;
float OutputLevel = 0.5f;
float ChorusWet = 0.99f;
float REC_vol = 0.5f;

static const int NUM_VOICES = 8;
Voice voices[NUM_VOICES];

MidiUartHandler midi;
Oscillator      lfo;
Chorus          chorus;

// ----------------------------
// CONTROLLO DA ESP32 (MIDI CC)
// ----------------------------
float cc_values[128]  = {0.0f};
float cc_smooth[128]  = {0.0f};

// ----------------------------
// SMOOTHING
// ----------------------------
float Smooth(float in, float &mem, float coeff)
{
    mem = mem + coeff * (in - mem);
    return mem;
}

// ----------------------------
// INIZIALIZZA VOCE
// ----------------------------
void VoiceInit(Voice &v)
{
    float sr = hw.AudioSampleRate();

    v.osc1.Init(sr);
    v.osc2.Init(sr);

    v.osc1.SetWaveform(Oscillator::WAVE_SAW);
    v.osc2.SetWaveform(Oscillator::WAVE_SAW);

    v.osc1.SetAmp(0.5f);
    v.osc2.SetAmp(0.5f);

    v.amp_env.Init(sr);
    v.amp_env.SetTime(ADSR_SEG_ATTACK, 0.01f);
    v.amp_env.SetTime(ADSR_SEG_DECAY, 0.1f);
    v.amp_env.SetSustainLevel(0.7f);
    v.amp_env.SetTime(ADSR_SEG_RELEASE, 0.2f);

    v.filt_env.Init(sr);
    v.filt_env.SetTime(ADSR_SEG_ATTACK, 0.02f);
    v.filt_env.SetTime(ADSR_SEG_DECAY, 0.15f);
    v.filt_env.SetSustainLevel(0.0f);
    v.filt_env.SetTime(ADSR_SEG_RELEASE, 0.2f);

    v.svf.Init(sr);
    v.svf.SetRes(0.7f);

    v.gate    = false;
    v.freq    = 0.0f;
    v.note    = -1;
    v.osc_mix = 0.5f;
    v.detune  = 0.0f;

    v.amp_env_last = 0.0f;
}

// ----------------------------
// NOTE ON
// ----------------------------
void VoiceNoteOn(int v, int note)
{
    float freq = mtof(note);

    voices[v].freq = freq;
    voices[v].note = note;

    voices[v].osc1.SetFreq(freq);
    voices[v].osc2.SetFreq(freq * ratio);

    voices[v].gate = true;

    lfo.Reset();
}

// ----------------------------
// NOTE OFF
// ----------------------------
void VoiceNoteOff(int v)
{
    voices[v].gate = false;
    voices[v].note = -1;
}

// ----------------------------
// TROVA VOCE LIBERA
// ----------------------------
int FindFreeVoice()
{
    for(int i = 0; i < NUM_VOICES; i++)
        if(!voices[i].gate)
            return i;

    float min_env = 999.0f;
    int   steal   = 0;

    for(int i = 0; i < NUM_VOICES; i++)
    {
        float e = voices[i].amp_env_last;
        if(e < min_env)
        {
            min_env = e;
            steal   = i;
        }
    }
    return steal;
}

// ----------------------------
// TROVA VOCE PER NOTA
// ----------------------------
int FindVoiceByNote(int note)
{
    for(int i = 0; i < NUM_VOICES; i++)
        if(voices[i].note == note)
            return i;

    return -1;
}

// ----------------------------
// ARPEGGIATORE: funzioni
// ----------------------------

// xorshift32, usato solo dalla modalita' RANDOM
uint32_t ArpRandom()
{
    arp_rng_state ^= arp_rng_state << 13;
    arp_rng_state ^= arp_rng_state >> 17;
    arp_rng_state ^= arp_rng_state << 5;
    return arp_rng_state;
}

// insertion sort, held_count e' sempre piccolo (<=16)
void ArpSortNotes(int *arr, int n)
{
    for(int i = 1; i < n; i++)
    {
        int key = arr[i];
        int j   = i - 1;
        while(j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// ricostruisce l'elenco di note da percorrere, in ordine ascendente,
// a partire dalle note tenute ordinate ed espanse sul numero di ottave scelto
void ArpBuildPool()
{
    if(held_count == 0)
    {
        arp_pool_len = 0;
        arp_step     = 0;
        arp_dir      = 1;
        return;
    }

    int sorted[16];
    for(int i = 0; i < held_count; i++)
        sorted[i] = held_notes[i];

    ArpSortNotes(sorted, held_count);

    int len = 0;
    for(int oct = 0; oct < arp_octaves; oct++)
        for(int i = 0; i < held_count; i++)
            arp_pool[len++] = sorted[i] + oct * 12;

    arp_pool_len = len;

    if(arp_step >= arp_pool_len)
        arp_step = 0;
}

void ArpAddHeldNote(int note)
{
    for(int i = 0; i < held_count; i++)
        if(held_notes[i] == note)
            return; // gia' tenuta

    if(held_count < 16)
        held_notes[held_count++] = note;

    ArpBuildPool();
}

void ArpRemoveHeldNote(int note)
{
    for(int i = 0; i < held_count; i++)
    {
        if(held_notes[i] == note)
        {
            for(int j = i; j < held_count - 1; j++)
                held_notes[j] = held_notes[j + 1];
            held_count--;
            break;
        }
    }

    ArpBuildPool();

    if(held_count == 0 && arp_voice >= 0)
    {
        VoiceNoteOff(arp_voice);
        arp_voice = -1;
    }
}

// chiamata al ritmo impostato da Ad11: spegne lo step precedente
// e accende la nota successiva secondo la modalita' scelta
void ArpAdvanceStep()
{
    if(arp_pool_len == 0)
    {
        if(arp_voice >= 0)
        {
            VoiceNoteOff(arp_voice);
            arp_voice = -1;
        }
        return;
    }

    int note = arp_pool[0];

    switch(arp_mode)
    {
        case ARP_UP:
            note     = arp_pool[arp_step];
            arp_step = (arp_step + 1) % arp_pool_len;
            break;

        case ARP_DOWN:
            note     = arp_pool[arp_pool_len - 1 - arp_step];
            arp_step = (arp_step + 1) % arp_pool_len;
            break;

        case ARP_UPDOWN:
            note = arp_pool[arp_step];
            if(arp_pool_len > 1)
            {
                arp_step += arp_dir;
                if(arp_step >= arp_pool_len - 1)
                {
                    arp_step = arp_pool_len - 1;
                    arp_dir  = -1;
                }
                else if(arp_step <= 0)
                {
                    arp_step = 0;
                    arp_dir  = 1;
                }
            }
            break;

        case ARP_RANDOM:
            note = arp_pool[ArpRandom() % arp_pool_len];
            break;
    }

    if(arp_voice >= 0)
        VoiceNoteOff(arp_voice);

    arp_voice = FindFreeVoice();
    VoiceNoteOn(arp_voice, note);
    arp_current_note = note;
}

// ----------------------------
// MIDI HANDLER
// ----------------------------
void HandleMidiMessage(MidiEvent m)
{
    switch(m.type)
    {
        case NoteOn:
        {
            auto msg = m.AsNoteOn();
            if(msg.velocity > 0)
            {
                if(arp_enabled)
                    ArpAddHeldNote(msg.note);
                else
                {
                    int v = FindFreeVoice();
                    VoiceNoteOn(v, msg.note);
                }
            }
            else // velocity 0 = note off mascherato, alcuni controller lo usano cosi'
            {
                if(arp_enabled)
                    ArpRemoveHeldNote(msg.note);
                else
                {
                    int v = FindVoiceByNote(msg.note);
                    if(v >= 0)
                        VoiceNoteOff(v);
                }
            }
        }
        break;

        case NoteOff:
        {
            auto msg = m.AsNoteOff();

            if(arp_enabled)
                ArpRemoveHeldNote(msg.note);
            else
            {
                int v = FindVoiceByNote(msg.note);
                if(v >= 0)
                    VoiceNoteOff(v);
            }
        }
        break;

        case ControlChange:
        {
            auto msg = m.AsControlChange();
            uint8_t cc  = msg.control_number;
            uint8_t val = msg.value;
            cc_values[cc] = val / 127.0f;
        }
        break;

        default: break;
    }
}

// ----------------------------
// AUDIO CALLBACK
// ----------------------------
void AudioCallback(AudioHandle::InterleavingInputBuffer in,
                   AudioHandle::InterleavingOutputBuffer out,
                   size_t size)
{
    midi.Listen();
    while(midi.HasEvents())
        HandleMidiMessage(midi.PopEvent());

    // ----------------------------
    // ARPEGGIATORE: avanzamento step
    // ----------------------------
    if(arp_enabled)
    {
        arp_sample_cnt += size / 2; // size conta L+R interleaved, quindi size/2 frame

        if(arp_sample_cnt >= arp_interval_samples)
        {
            arp_sample_cnt = 0;
            ArpAdvanceStep();
        }
    }

    for(size_t i = 0; i < size; i += 2)
    {
        float mix = 0.0f;

        float lfo_val = lfo.Process();

        // SINTESI VOCI
        for(int v = 0; v < NUM_VOICES; v++)
        {
            float env_amp  = voices[v].amp_env.Process(voices[v].gate);
            float env_filt = voices[v].filt_env.Process(voices[v].gate);

            voices[v].amp_env_last = env_amp;

            if(env_amp < 0.0001f)
                continue;

            float s1  = voices[v].osc1.Process();
            float s2  = voices[v].osc2.Process();
            
            if (D0)
                sig = voices[v].osc_mix * s1;
            else
                sig = (1.0f - voices[v].osc_mix) * s1 + voices[v].osc_mix * s2;

            if (!D2)
                cutoff = g_cutoff;
            else
            {
                cutoff = !D1 ? (300.0f + lfo_val * 7000.0f)
                            : (300.0f + env_filt * 7000.0f);

                cutoff = fclamp(cutoff, 50.0f, 15000.0f);
            }

            voices[v].svf.SetFreq(cutoff);
            voices[v].svf.Process(sig * env_amp);

            if (!D3)
                mix += voices[v].svf.High();
            else
                mix += voices[v].svf.Low();
        }

        // CHORUS
        if (!D7)
        {
            float chorus_out = chorus.Process(mix);
            mix = (1.0f - ChorusWet) * mix + ChorusWet * chorus_out;
        }

        // ----------------------------
        // SDRAM RECORDING
        // ----------------------------
        if(is_recording)
        {
            if(write_idx < SDRAM_SIZE)
                sdram_buffer[write_idx++] = mix;
        }

        // ----------------------------
        // SDRAM PLAYBACK
        // ----------------------------
        float playback = 0.0f;

        if(is_playing && recorded_len > 0)
        {
            playback = sdram_buffer[read_idx++];

            if(read_idx >= recorded_len)
                read_idx = 0; // loop esattamente sulla lunghezza registrata
        }

        // MIX FINALE: SYNTH + LOOP
        float final_out = mix;

        if(is_playing)
            final_out += playback * REC_vol;

        if(!D4)
        {
            out[i]     = final_out * OutputLevel + in[i] * InputLevel;
            out[i + 1] = final_out * OutputLevel + in[i + 1] * InputLevel;
        }
        else
        {
            out[i]     = final_out * OutputLevel;
            out[i + 1] = final_out * OutputLevel;
        }
    }
}

// ----------------------------
// MAIN
// ----------------------------
int main(void)
{
    hw.Init();
    hw.SetAudioBlockSize(48);

    float sr = hw.AudioSampleRate();
    
    // LFO
    lfo.Init(sr);
    lfo.SetWaveform(Oscillator::WAVE_SIN);
    lfo.SetFreq(0.5f);
    lfo.SetAmp(1.0f);

    // ADC
    // Ad0..Ad9 sui pin 15..24 (esistenti). Ad10 e Ad11 (arpeggiatore) sono
    // cablati sui pin dedicati all'arpeggiatore: attenzione, sul Daisy Seed
    // i pin ADC non sono numerati in modo contiguo (33 e 34 non sono ADC-capable),
    // quindi ADC11 va assegnato esplicitamente al pin 35.
    AdcChannelConfig adc_cfg[12];
    for(int i = 0; i < 11; i++)
        adc_cfg[i].InitSingle(hw.GetPin(15 + i)); // Ad0..Ad10 -> pin 15..25

    adc_cfg[11].InitSingle(hw.GetPin(28));        // Ad11 -> pin 28

    hw.adc.Init(adc_cfg, 12);
    hw.adc.Start();

    // CHORUS
    chorus.Init(hw.AudioSampleRate());
    chorus.SetLfoFreq(0.8f);
    chorus.SetLfoDepth(1.0f);
    chorus.SetFeedback(0.3f);
    chorus.SetDelayMs(25.0f);

    // Voci
    for(int i = 0; i < NUM_VOICES; i++)
        VoiceInit(voices[i]);

    // MIDI UART
    MidiUartHandler::Config midi_cfg;
    midi.Init(midi_cfg);

    hw.StartAudio(AudioCallback);
    float smA[12] = {0};

    
    while(1)
    {
        // smoothing CC
        for(int i = 0; i < 128; i++)
            cc_smooth[i] = Smooth(cc_values[i], cc_smooth[i], 0.05f);
       
        // Mappatura potenziometri ESP
        float A0  = cc_smooth[10]; // OSC Attack
        float A1  = cc_smooth[11]; // OSC Decay
        float A2  = cc_smooth[12]; // OSC Sustain
        float A3  = cc_smooth[13]; // OSC Release
        float A4  = cc_smooth[14]; // OSC Waveform
        float A5  = cc_smooth[15]; // Detune coarse
        float A6  = cc_smooth[16]; // Detune fine
        float A7  = cc_smooth[17]; // POLY Waveform
        float A8  = cc_smooth[18]; // OSC1-OSC2 Mix
        float A9  = cc_smooth[19]; // FILT Attack
        float A10 = cc_smooth[20]; // FILT Decay
        float A11 = cc_smooth[21]; // FILT Sustain
        float A12 = cc_smooth[22]; // FILT Release
        float A13 = cc_smooth[23]; // LFO Rate
        float A14 = cc_smooth[24]; // LFO Waveform

        D0 = cc_smooth[30] > 0.5f; // POLY ON-OFF
        D1 = cc_smooth[31] > 0.5f; // LFO vs ENV sul cutoff
        D2 = cc_smooth[32] > 0.5f; // ADSR-LFO vs cutoff fisso
        D3 = cc_smooth[33] > 0.5f; // HPF vs LPF
        D4 = cc_smooth[34] > 0.5f; // Feedback loop input
        D5 = cc_smooth[35] > 0.5f; // REC
        D6 = cc_smooth[36] > 0.5f; // PLAY
        D7 = cc_smooth[37] > 0.5f; // CHORUS

        float Ad0 = Smooth(hw.adc.GetFloat(0), smA[0], 0.01f); // cutoff globale, usata se D0 è attivo
        float Ad1 = Smooth(hw.adc.GetFloat(1), smA[1], 0.01f); // res globale, usata se D1 è attivo
        float Ad2 = Smooth(hw.adc.GetFloat(2), smA[2], 0.01f); // Livello di input per feedback
        float Ad3 = Smooth(hw.adc.GetFloat(3), smA[3], 0.01f); // Livello di output
        float Ad4 = Smooth(hw.adc.GetFloat(4), smA[4], 0.01f); // LFO rate per chorus
        float Ad5 = Smooth(hw.adc.GetFloat(5), smA[5], 0.01f); // LFO depth per chorus
        float Ad6 = Smooth(hw.adc.GetFloat(6), smA[6], 0.01f); // Feedback per chorus
        float Ad7 = Smooth(hw.adc.GetFloat(7), smA[7], 0.01f); // Delay per chorus
        float Ad8 = Smooth(hw.adc.GetFloat(8), smA[8], 0.01f); // Chorus wet
        float Ad9 = Smooth(hw.adc.GetFloat(9), smA[9], 0.01f); // REC volume
        float Ad10 = Smooth(hw.adc.GetFloat(10), smA[10], 0.01f); // ARP: modalita' (OFF / ottave 2-5 x UP-DOWN-UPDOWN-RANDOM)
        float Ad11 = Smooth(hw.adc.GetFloat(11), smA[11], 0.01f); // ARP: intervallo tra le note

        // ----------------------------
        // ARPEGGIATORE: lettura Ad10 (on/off + ottave + modalita') e Ad11 (intervallo)
        // ----------------------------
        bool arp_enabled_new = Ad10 > 0.05f; // sotto questa soglia: arpeggiatore spento

        if(arp_enabled_new != arp_enabled)
        {
            arp_enabled = arp_enabled_new;

            if(!arp_enabled)
            {
                // appena disattivato: spegni la voce e dimentica le note tenute,
                // altrimenti restano note "appese"
                if(arp_voice >= 0)
                {
                    VoiceNoteOff(arp_voice);
                    arp_voice = -1;
                }
                held_count   = 0;
                arp_pool_len = 0;
            }
        }

        if(arp_enabled)
        {
            // range utile del potenziometro dopo la soglia OFF, diviso in 16 zone:
            // 4 range di ottave (2,3,4,5) x 4 modalita' (UP, DOWN, UPDOWN, RANDOM)
            float range = (Ad10 - 0.05f) / 0.95f;
            range        = fclamp(range, 0.0f, 0.9999f);

            int zone = (int)(range * 16.0f); // 0..15

            int     new_octaves = 2 + (zone / 4);        // 2,3,4,5
            ArpMode new_mode    = (ArpMode)(zone % 4);    // UP,DOWN,UPDOWN,RANDOM

            if(new_octaves != arp_octaves || new_mode != arp_mode)
            {
                arp_octaves = new_octaves;
                arp_mode    = new_mode;
                arp_step    = 0;
                arp_dir     = 1;
                ArpBuildPool();
            }
        }

        // intervallo tra le note: suddivisione musicale scelta da Ad11 (da 1/16
        // in terzina a nota intera) al tempo di riferimento arp_bpm
        int div_zone = (int)(Ad11 * 8.0f);
        if(div_zone > 7) div_zone = 7;
        if(div_zone < 0) div_zone = 0;

        float quarter_note_ms = 60000.0f / arp_bpm;
        float arp_interval_ms = ARP_DIVISIONS[div_zone] * quarter_note_ms;

        arp_interval_samples  = (size_t)(arp_interval_ms * 0.001f * sr);

        InputLevel = Ad2 * 1.25f + 0.05f; // Livello di input per feedback
        OutputLevel = Ad3 * 0.95f + 0.05f; // Livello di output
        
        // Detune globale
        int   coarse             = (A5 * 2.0f - 1.0f) * 3.0f;   // da -3 a +3 ottave
        float detune_fine_cents  = (A6 * 100.0f) - 50.0f;      // -50 .. +50 cent
        float fine               = detune_fine_cents / 1200.0f;
        float ratio_local        = powf(2.0f, coarse + fine);
        ratio = ratio_local; // aggiorno globale usata in VoiceNoteOn

        g_cutoff = 300.0f + Ad0 * 9000.0f; // cutoff globale, usata se D0 è attivo

        int wave_lfo = (A14 < 0.25f) ? 0 : (A14 < 0.5f) ? 2 : (A14 < 0.75f) ? 1 : 3;
        int wave_1   = (A4 < 0.25f) ? 0 : (A4 < 0.5f) ? 2 : (A4 < 0.75f) ? 1 : 3;
        int wave_2   = (A7 < 0.25f) ? 0 : (A7 < 0.5f) ? 2 : (A7 < 0.75f) ? 1 : 3;

        // LFO rate and waveform
        lfo.SetFreq(0.01f + A13 * 10.0f);
        lfo.SetWaveform(wave_lfo);

        // Chorus parameters
        chorus.SetLfoFreq(2.0f * Ad4);
        chorus.SetLfoDepth(Ad5);
        chorus.SetFeedback(Ad6);
        chorus.SetDelayMs(50.0f*Ad7);
        ChorusWet = Ad8 * 1.25f + 0.05f; // Chorus wet
        // REC volume
        REC_vol = Ad9  * 1.25f + 0.05f;

        // ----------------------------
        // LOOPER STATE MACHINE
        // ----------------------------

        // RECORD ON
        if(!D5 && !is_recording)
        {
            is_recording = true;
            is_playing   = false;

            write_idx    = 0;
            recorded_len = 0;

            for(size_t i = 0; i < SDRAM_SIZE; i++)
                sdram_buffer[i] = 0.0f;
        }

        // RECORD OFF
        if(D5 && is_recording)
        {
            is_recording = false;
            recorded_len = write_idx; // lunghezza esatta registrata
        }

        // PLAY ON
        if(!D6 && !is_playing && recorded_len > 0)
        {
            is_playing = true;
            read_idx   = 0;
        }

        // PLAY OFF
        if(D6 && is_playing)
        {
            is_playing = false;
        }

        // ----------------------------
        // UPDATE VOICES
        // ----------------------------
        for(int v = 0; v < NUM_VOICES; v++)
        {
            voices[v].osc2.SetFreq(voices[v].freq * ratio);

            voices[v].osc_mix = A8; // mix osc1/osc2

            voices[v].svf.SetRes(0.3f + Ad1 * 0.69f);

            voices[v].osc1.SetWaveform(wave_1);
            voices[v].osc2.SetWaveform(wave_2);

            // Amp envelope
            voices[v].amp_env.SetTime(ADSR_SEG_ATTACK,  A0);
            voices[v].amp_env.SetTime(ADSR_SEG_DECAY,   A1);
            voices[v].amp_env.SetSustainLevel(          A2);
            voices[v].amp_env.SetTime(ADSR_SEG_RELEASE, A3);

            // Filter envelope
            voices[v].filt_env.SetTime(ADSR_SEG_ATTACK,  A9);
            voices[v].filt_env.SetTime(ADSR_SEG_DECAY,   A10);
            voices[v].filt_env.SetSustainLevel(          A11);
            voices[v].filt_env.SetTime(ADSR_SEG_RELEASE, A12);
        }
    }
}
